def_pecas:-
    new_frame(pecas),
    new_slot(pecas,nome),
    new_slot(pecas,quantidade).



gen_piece(NomeFab):-
  write('Nome da pe�a'),
  read(PieceName),
  new_frame(PieceName),
  new_slot(PieceName,is_a,pecas),
  new_slot(PieceName,is_in,NomeFab),
  write('Stock: '),
  read(Stock),
  new_slot(PieceName,quantidade,Stock).




get_piece_stock(NomePeca,N):-
  get_value(NomePeca,quantidade,N).
